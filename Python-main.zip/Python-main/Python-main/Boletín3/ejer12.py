"""12. Las matrículas españolas constan de un número de cuatro dígitos y tres letras
cualesquiera en mayúsculas a excepción de las vocales, la Ñ y la Q. Escribe un
programa que detecte si una matrícula introducida por teclado es válida o no."""
import re

#* ----------------------- DECLARAMOS VARIBLES ---------------------
# Esta variable, es el patrón por el cual, se regira todas las matriculas.
patron = r"[0-9]{4}[BCDFGHJKLMNPRSTVWXYZ]{3}"
# Una variable de las importante; es el controlador, para detener un bucle while.
salir = False

#* ------------------------- LUGAR LOGICO ----------------------------
# Este bucle while, lo que hace es tener la logica del programa
# mientras que la condición no funcione y se cambie su variable, sera ejecutandose
while not salir:
    # El try maneja lo que es la logica, al mismo tiempo, comprobamos si el patron funciona
    try:
        matricula = input("Introduce una matricula(ej.4325SFG): ")
        # Aqui es donde veremos si el patron es igual a la matricula.
        if re.fullmatch(patron, matricula):
            print("Funciona")
        # Por si acaso, tenemos un raise que salte un error, sin no encuentra coincidencias
        else:
            raise  Exception ("La matricula no ha sido encontrada, has introducido bien la matricula.")
    # Por si el usuario es mas listo y quiere meter algo que no sea una matricula
    except ValueError as e:
        print("Error, has introducido algo que no es una matricula.",e)
    except:
        print("Error, has introducido algo que no es una matricula.")

    # Aqui cambiaremos la variable de salida, asi como mostrar mas datos.
    else:
        # Creamos un informe, donde metemos la matricula y mostramos un mensaje
        print("Saliendo...")
        informacion = f"""
        tu matricula es {matricula}
        ha sido encontrada, tu coche
        ha sido registrado
"""
        # Mostramos el informe.
        print(informacion)
        # Cambiamos la variable de salida.
        salir = True
